
import torch
import cv2
# import

def perturbation_forseg(image,cluster_pred,target_class,num_token,mode="mask", perturbation_strength=0.5, blur_intensity=3, perturbation_type="positive"):
    
    image = image.clone()

    if perturbation_type == "positive":
        mask = (cluster_pred == target_class) #& (relevance_map[i] < 0.9) # Select top 50% of relevant patches
        # mask = relevance_map[i] < 0.95
    elif perturbation_type == "negative":
        mask = (cluster_pred != target_class)  # Select bottom 20% least relevant patches

    if mode == "mask":
        image[:, mask.squeeze()] = 0  # Zero-out pixels
        
    elif mode == "noise":
        noise = torch.randn_like(image) * perturbation_strength
        image[:, mask.squeeze()] += noise[:, mask.squeeze()]
    
    elif mode == "blur":
        image = F.avg_pool2d(image.unsqueeze(0), kernel_size=blur_intensity, stride=1, padding=blur_intensity//2).squeeze(0)

    return image,cv2.resize(cluster_pred, (num_token, num_token), interpolation=cv2.INTER_NEAREST)!= target_class