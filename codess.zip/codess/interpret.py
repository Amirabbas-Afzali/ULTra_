
import torch
from torch import nn
import torch.nn.functional as F

def interpret_token_dino(image, layer, token_id, model, device,func=torch.sum, texts=None):
    attn_blocks = [i for i in model.blocks.children()]

    x = model.prepare_tokens(image)
    for i in range(len(attn_blocks)):
        x = attn_blocks[i](x)
        if i+2 == layer:
            # print(x.shape)
            token = x[:,token_id]
    x = model.norm(x)

    batch_size = image.shape[0]
    token = token.cuda() 
    token = token/torch.norm(token.detach())

    token_sum = func(token) #* random_vector)
    model.zero_grad()
    num_tokens = attn_blocks[0].attn.attn_probs.shape[-1]
    R = torch.eye(num_tokens, num_tokens,
                  dtype=attn_blocks[0].attn.attn_probs.dtype).to(device)
    R = R.unsqueeze(0).expand(batch_size, num_tokens, num_tokens)
    normal = 0
    for i, blk in enumerate(attn_blocks):
        if i+1 >= layer:
            continue
        normal += 1
        grad = torch.autograd.grad(
            token_sum, [blk.attn.attn_probs], retain_graph=True, allow_unused=True)
        grad = grad[0].detach()
        cam = blk.attn.attn_probs.detach()
        cam = cam.reshape(-1, cam.shape[-1], cam.shape[-1])
        grad = grad.reshape(-1, grad.shape[-1], grad.shape[-1])
        cam = grad * cam
        cam = cam.reshape(batch_size, -1, cam.shape[-1], cam.shape[-1])
        cam = cam.clamp(min=0).mean(dim=1)
        R = R + torch.bmm(cam, R)

    image_relevance = R[:, token_id, 1:]
    return image_relevance,token  # [batch* patch * patch]
    
def interpret_token_dino2(image, layer, token_id, model, device,func=torch.sum, texts=None):
    attn_blocks = [i for i in model.blocks.children()]

    x = model.prepare_tokens_with_masks(image)
    for i in range(len(attn_blocks)):
        x = attn_blocks[i](x)
        if i+2 == layer:
            # print(x.shape)
            token = x[:,token_id]
    x = model.norm(x)

    batch_size = image.shape[0]
    token = token.cuda() 
    token = token/torch.norm(token.detach())

    token_sum = func(token) #* random_vector)
    model.zero_grad()
    num_tokens = attn_blocks[0].attn.attn_probs.shape[-1]
    R = torch.eye(num_tokens, num_tokens,
                  dtype=attn_blocks[0].attn.attn_probs.dtype).to(device)
    R = R.unsqueeze(0).expand(batch_size, num_tokens, num_tokens)
    normal = 0
    for i, blk in enumerate(attn_blocks):
        if i+1 >= layer:
            continue
        normal += 1
        grad = torch.autograd.grad(
            token_sum, [blk.attn.attn_probs], retain_graph=True, allow_unused=True)
        grad = grad[0].detach()
        cam = blk.attn.attn_probs.detach()
        cam = cam.reshape(-1, cam.shape[-1], cam.shape[-1])
        grad = grad.reshape(-1, grad.shape[-1], grad.shape[-1])
        cam = grad * cam
        cam = cam.reshape(batch_size, -1, cam.shape[-1], cam.shape[-1])
        cam = cam.clamp(min=0).mean(dim=1)
        R = R + torch.bmm(cam, R)

    image_relevance = R[:, token_id, 1:]
    return image_relevance,token  # [batch* patch * patch]

def interpret_token_clip(image, layer, token_id, model, device,func=torch.sum, texts=None):
    attn_blocks = [i for i in model.visual.transformer.resblocks.children()]

    x = model.visual.conv1(image.type(torch.cuda.HalfTensor))
    # shape = [*, width, grid ** 2]   [B, channel, H*W]
    x = x.reshape(x.shape[0], x.shape[1], -1)
    # shape = [*, grid ** 2, width]       [B, H*W, channel]
    x = x.permute(0, 2, 1)
    x = torch.cat([model.visual.class_embedding.to(x.dtype) + torch.zeros(x.shape[0], 1, x.shape[-1],
                  dtype=x.dtype, device=x.device), x], dim=1)  # shape = [*, grid ** 2 + 1, width]
    x = x + model.visual.positional_embedding.to(x.dtype)
    x = model.visual.ln_pre(x)
    x = x.permute(1, 0, 2)  # NLD -> LND    [H*W, B, channel]
    for i in range(len(attn_blocks)):
        x = attn_blocks[i](x)
        if i+2 == layer:
            token = x[token_id]
    x = x.permute(1, 0, 2)
    x = x = model.visual.ln_post(x[:, 0, :])
    final = x @ model.visual.proj

    batch_size = image.shape[0]
    token = token.cuda() 
    token = token/torch.norm(token.detach())
    # random_vector = torch.randn_like(token)
    
    # token_sum = torch.norm()
    # print(random_vector.shape,token.shape)
    # token_sum = torch.dot(token, random_vector)
    token_sum = func(token) #* random_vector)
    # print(token_sum.shape)
    # print(torch.norm(token).shape)
    model.zero_grad()

    num_tokens = attn_blocks[0].attn_probs.shape[-1]

    R = torch.eye(num_tokens, num_tokens,
                  dtype=attn_blocks[0].attn_probs.dtype).to(device)
    R = R.unsqueeze(0).expand(batch_size, num_tokens, num_tokens)
    normal = 0
    for i, blk in enumerate(attn_blocks):
        if i+1 >= layer:
            continue
        normal += 1
        grad = torch.autograd.grad(
            token_sum, [blk.attn_probs], retain_graph=True, allow_unused=True)
        grad = grad[0].detach()
        cam = blk.attn_probs.detach()
        cam = cam.reshape(-1, cam.shape[-1], cam.shape[-1])
        grad = grad.reshape(-1, grad.shape[-1], grad.shape[-1])
        cam = grad * cam
        cam = cam.reshape(batch_size, -1, cam.shape[-1], cam.shape[-1])
        cam = cam.clamp(min=0).mean(dim=1)
        R = R + torch.bmm(cam, R)

    image_relevance = R[:, token_id, 1:]
    return image_relevance,token  # [batch* patch * patch]



class ULTraWeightLearner(nn.Module):
    def __init__(self, token_dim, num_tokens):
        super(ULTraWeightLearner, self).__init__()
        self.token_dim = token_dim
        self.num_tokens = num_tokens

        # Initialize theta with small random values to break symmetry
        self.theta = nn.Parameter(torch.randn(num_tokens, token_dim) * 0.1)

    def forward(self, z, z_tilde):
        """
        z: (batch_size, num_tokens, token_dim)
        z_tilde: (batch_size, num_tokens, token_dim)
        """
        batch_size = z.shape[0]
        z = z.float()
        z_tilde = z_tilde.float()

        # Normalize theta with a small perturbation to avoid collapse
        W = F.normalize(self.theta + 1e-8 * torch.randn_like(self.theta), p=2, dim=1)  
        
        print(W.shape)
        # Expand W to match batch size
        W = W.unsqueeze(0).expand(batch_size, -1, -1)
        print("after",W.shape)

        # Compute weighted difference
        weighted_difference = torch.bmm(W, (z - z_tilde).transpose(1, 2)) 
        print(weighted_difference.shape)
        # Compute L2 norm for each row
        divergence = torch.norm(weighted_difference, p=2, dim=2) ** 2  
        return divergence

    def self_consistency_loss(self, z, z_tilde):
        divergence = self.forward(z, z_tilde)
        loss = torch.sum(divergence, dim=1).mean()

        # Introduce weight regularization to encourage diversity
        reg_term = 0.01 * torch.norm(self.theta, p=2)  
        return loss + reg_term