import torch
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import pdist
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import numpy as np
import cv2
# from utils.seg_utils import interpret_token


def show_tensor_lable(image):
    plt.figure()
    image = image.data.cpu().numpy()
    plt.imshow(image)


def show_tensor_img(image):
    plt.figure()
    image = image.permute(1, 2, 0).data.cpu().numpy()
    image = (image - image.min()) / (image.max() - image.min())
    plt.imshow(image)


def show_tensor_image_label_prediction(image, label, prediction):
    """
    Displays an image tensor, its corresponding ground truth label, and the predicted label side by side.

    Args:
        image (torch.Tensor): The input image tensor (C, H, W).
        label (torch.Tensor): The ground truth label tensor (H, W).
        prediction (torch.Tensor): The predicted label tensor (H, W).
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    # Process Image
    image = image.permute(1, 2, 0).data.cpu().numpy()  # Convert (C, H, W) -> (H, W, C)
    image = (image - image.min()) / (image.max() - image.min())  # Normalize

    # Process Label
    label = label.data.cpu().numpy()  # Convert to NumPy

    # Process Prediction
    prediction = prediction.data.cpu().numpy()  # Convert to NumPy

    # Display Image
    axes[0].imshow(image)
    axes[0].set_title("Image")
    axes[0].axis("off")

    # Display Ground Truth Label
    axes[1].imshow(label)
    axes[1].set_title("Ground Truth Label")
    axes[1].axis("off")

    # Display Predicted Label
    axes[2].imshow(prediction)
    axes[2].set_title("Predicted Label")
    axes[2].axis("off")

    plt.show()




def show_image_relevance(image_relevance, image, title=None, patch_pos=None, patch_size=0,res=224):
    # create heatmap from mask on image
    def show_cam_on_image(img, mask):
        heatmap = cv2.applyColorMap(np.uint8(255 * mask), cv2.COLORMAP_JET)
        heatmap = np.float32(heatmap) / 255
        cam = heatmap + np.float32(img)
        cam = cam / np.max(cam)
        return cam

    fig, axs = plt.subplots(1, 2)
    image_np = image.permute(1, 2, 0).cpu().numpy()  # Convert to HWC and numpy
    image_np = (image_np - image_np.min()) / (image_np.max() - image_np.min())  # Normalize
    axs[0].imshow(image_np)
    axs[0].axis('off')

    dim = int(image_relevance.numel() ** 0.5)
    image_relevance = image_relevance.reshape(1, 1, dim, dim)
    image_relevance = torch.nn.functional.interpolate(
        image_relevance, size=res, mode='bilinear')
    image_relevance = image_relevance.reshape(
        res, res).cuda().data.cpu().numpy()
    image_relevance = (image_relevance - image_relevance.min()) / \
        (image_relevance.max() - image_relevance.min())
    image = image.permute(1, 2, 0).data.cpu().numpy()
    image = (image - image.min()) / (image.max() - image.min())
    vis = show_cam_on_image(image, image_relevance)
    vis = np.uint8(255 * vis)
    vis = cv2.cvtColor(np.array(vis), cv2.COLOR_RGB2BGR)

    if patch_pos and patch_size > 0:
        startj, starti = patch_pos
        # Change the rectangle color to purple (R:128, G:0, B:128)
        cv2.rectangle(vis, (startj, starti), (startj + patch_size, starti + patch_size), (128, 0, 128), 2)

    axs[1].imshow(vis)
    axs[1].axis('off')


def segment_img(image, image_relevance, threshold=0.4, plot=True):
    image = image[0].permute(1, 2, 0).data.cpu().numpy()
    image = (image - image.min()) / (image.max() - image.min())
    dim = int(image_relevance.numel() ** 0.5)
    image_relevance = image_relevance.reshape(1, 1, dim, dim)
    image_relevance = torch.nn.functional.interpolate(
        image_relevance, size=224, mode='bilinear')
    image_relevance = image_relevance.reshape(
        224, 224).cuda().data.cpu().numpy()
    mask = (image_relevance - image_relevance.min()) / \
        (image_relevance.max() - image_relevance.min())
    mask = (mask > threshold).astype(np.uint8)

    if plot:
        fig, axs = plt.subplots(1, 2)
        axs[0].imshow(image)
        axs[0].axis('off')
        axs[1].imshow(mask, cmap='jet')
        axs[1].axis('off')
        plt.show()
    return mask  # binary seg with one token


def plot_dendrogram_with_images(seg_features, images, threshold=0.5):
    """
    Plot a dendrogram with images at each node, with image sizes varying by tree depth.

    Args:
        seg_features (numpy.ndarray): Segment features for clustering.
        images (list of torch.Tensor): List of images to display at each node.
        threshold (float): Distance threshold for clustering.
    """
    # Calculate the cosine distance matrix and linkage
    cosine_distances = pdist(seg_features, metric='cosine')
    linkage_matrix = linkage(cosine_distances, method='average')

    # Plot dendrogram and get the positions of nodes
    fig, ax = plt.subplots(figsize=(15, 10))
    dendro = dendrogram(
        linkage_matrix, color_threshold=threshold, ax=ax, no_labels=True)

    # Retrieve the x and y positions of each leaf
    leaf_positions = dict(zip(dendro['leaves'], dendro['ivl']))
    node_positions = {}

    # Extract x, y coordinates for each node
    for i, dcoord in enumerate(dendro['dcoord']):
        # Calculate the x, y coordinates of each branch node
        # Midpoint of the x-coordinates of the branch
        x = np.mean(dendro['icoord'][i][1:3])
        y = dcoord[1]                          # Y-coordinate of the branch
        node_positions[i] = (x, y)

    # Add images at corresponding leaf nodes and branch nodes
    for i, pos in node_positions.items():
        # The i-th node corresponds to the i-th image
        if i < len(images):
            img = images[dendro['leaves'][i]]
        else:
            # Calculate average image for internal nodes (higher levels)
            img = np.mean([images[leaf] for leaf in dendro['leaves']], axis=0)

        img_np = img.cpu().numpy() if isinstance(img, torch.Tensor) else img
        img_np = (img_np - img_np.min()) / \
            (img_np.max() - img_np.min())  # Normalize

        # Improved scaling: Cap zoom_factor between 0.1 and 0.5
        max_depth = max(dendro['dcoord'][0])  # Maximum distance from the root
        zoom_factor = 0.1 + 0.4 * (pos[1] / max_depth)  # Adjusted scaling

        # Set up an offset box with the image at the corresponding node position
        im = OffsetImage(img_np, zoom=zoom_factor/30, cmap='viridis')
        ab = AnnotationBbox(im, (pos[0], pos[1]),
                            frameon=False, xycoords='data', pad=0)
        ax.add_artist(ab)

    # Add a threshold line
    plt.axhline(y=threshold, color='r', linestyle='--', label="Threshold")
    plt.legend()
    plt.xlabel("Segment Index")
    plt.ylabel("Cosine Distance")
    plt.title(f"Dendrogram with Images at Nodes, Threshold {threshold:.2f}")
    plt.show()


def visualize_segmentation_with_dendrogram(image, model, res=224, layer=13, threshold=0.5):
    """
    Visualize segmentation at different thresholds and display a combined dendrogram with images.

    Args:
        image (torch.Tensor): Original image.
        model: Model to generate segment features.
        res (int): Resolution for image upsampling.
        layer (int): Model layer for feature extraction.
        threshold (float): Distance threshold for clustering.
    """
    seg_features = []
    images = []

    for token in range(1, 50):
        R_image = interpret_token(
            layer=layer, token_id=token, model=model, image=image, device=device)
        R_image[:, token - 1] = 0
        R_image[:, token - 1] = torch.max(R_image, axis=1)[0]
        R_image = R_image.reshape(-1, 7, 7).unsqueeze(1)
        R_image = torch.nn.functional.interpolate(
            R_image, size=res, mode='bicubic').squeeze(1)

        seg_features.append(R_image.cpu().reshape(-1, res * res).numpy())
        images.append(R_image.cpu().reshape(res, res))

    seg_features = np.concatenate(seg_features, axis=0)

    # Plot dendrogram with images at nodes, using dynamic scaling for each node
    plot_dendrogram_with_images(seg_features, images, threshold=threshold)
