import torch
import json
from models.clip_model import load_clip_model
from datasets.dataset_loader import build_dataset
from datasets.dataset_loader import build_dataloader

def preprocess_image_relevance(relevance, token, num_token=7, res=224,  mode='bicubic'):
    r_image = relevance
    r_image[:, token - 1] = 0
    r_image[:, token - 1] = torch.max(r_image, axis=1)[0]
    r_image = r_image.reshape(-1, num_token, num_token)
    # if batch!=1:
    r_image = r_image.unsqueeze(1)  # Now shape is (batch, 1, 7, 7)

    # Resize each image in the batch to 224x224
    r_image = torch.nn.functional.interpolate(
        r_image, size=res, mode=mode)

    # Remove the channel dimension if not needed, resulting in (8, 224, 224)
    r_image = r_image.squeeze(1)
    r_image = r_image.reshape(-1, res*res)
    return r_image


def map_to_sequential_indices(tensor):
    # Find unique values in the tensor and sort them
    unique_vals = torch.unique(tensor)

    # Create a mapping from unique values to sequential indices
    mapping = {val.item(): idx for idx, val in enumerate(unique_vals)}

    # Apply the mapping to the tensor
    mapped_tensor = tensor.clone()
    for val, idx in mapping.items():
        mapped_tensor[tensor == val] = idx

    return mapped_tensor

def load_config(config_file):
    with open(config_file, 'r') as file:
        return json.load(file)

def prepare_evaluation(config_path="configs/coco.json"):
    """
    Prepares the necessary inputs for evaluation from the configuration file.

    Args:
        config_path: Path to the configuration JSON file.

    Returns:
        config: Loaded configuration.
        model: Loaded model.
        dataset: Prepared dataset.
        dataloader: DataLoader for the dataset.
        device: The device (CPU or GPU).
    """
    # Load config
    torch.hub.set_dir('ROOT_PATH/ULTra/models')
    config = load_config(config_path)
    # Set device to CUDA or CPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Load the model and preprocessing function
    if config["model"]["model"] == "clip":
        model, preprocess = load_clip_model(config["model"]["name"], device=device)
    elif config["model"]["model"] == "dino":
        if config["model"]["name"]=='ViT-B/16':
            model_name = 'dino_vitb16'
        elif config["model"]["name"]=='ViT-S/16':
            model_name = 'dino_vits16'
        elif config["model"]["name"]=='ViT-B/8':
            model_name = 'dino_vitb8'
        elif config["model"]["name"]=='ViT-S/8':
            model_name = 'dino_vits8'
        
        model = torch.hub.load('facebookresearch/dino:main', model_name)

    elif config["model"]["model"] == "dino2":
        if config["model"]["name"]=='ViT-B/14':
            model_name = 'dinov2_vitb14'
        elif config["model"]["name"]=='ViT-S/14':
            model_name = 'dinov2_vits14'
        elif config["model"]["name"]=='ViT-L/14':
            model_name = 'dinov2_vitl14'
        elif config["model"]["name"]=='ViT-G/14':
            model_name = 'dinov2_vitg14'
        elif config["model"]["name"]=='regViT-B/14':
            model_name = 'dinov2_vitb14_reg'
        else:
            print('model-not-found')
        model = torch.hub.load('facebookresearch/dinov2', model_name)


        
    
    # Build the dataset and dataloader
    dataset = build_dataset(config["dataset"])
    dataloader = build_dataloader(dataset, config["dataloader"], shuffle=False,
                                  batch_size=config["dataloader"]["batch_size"])
    model = model.to(device)

    return config, model, dataloader, device

def postprocess_image_relevance(relevance, token, num_token=7, res=224,  mode='bicubic'):
    r_image = relevance
    r_image[:, token - 1] = 0
    r_image[:, token - 1] = torch.max(r_image, axis=1)[0]
    r_image = r_image.reshape(-1, num_token, num_token)
    # if batch!=1:
    r_image = r_image.unsqueeze(1)  # Now shape is (batch, 1, 7, 7)

    # Resize each image in the batch to 224x224
    r_image = torch.nn.functional.interpolate(
        r_image, size=res, mode=mode)

    # Remove the channel dimension if not needed, resulting in (8, 224, 224)
    r_image = r_image.squeeze(1)
    r_image = r_image.reshape(-1, res*res)
    return r_image