from scipy.spatial.distance import pdist, squareform
import torch
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import pdist
import cv2
import numpy as np
from utils.preprocess import preprocess_image_relevance
from utils.interpret import interpret_token_clip, interpret_token_dino, interpret_token_dino2
from tqdm import tqdm
from copy import deepcopy
import torch
from datasets.dataset_loader import ContrastiveSegDataset
from utils.evaluation_metrics import calculate_metrics, get_metrics, UnsupervisedMetrics
from models.clip_model import load_clip_model
from utils.visualization import show_tensor_img
from utils.visualization import show_tensor_lable
from utils.visualization import show_tensor_image_label_prediction
from utils.preprocess import map_to_sequential_indices, prepare_evaluation


def retrive_func(f):
    if f=='sum':
        func = torch.sum
    elif f=='norm':
        func = torch.norm
    else:
        return None
    return func

def return_func(w):
    def func(token):
        return torch.sum(token*w)
    return func

def unsup_seg(image,num_unique_classes, model, device, layer=13, distance_threshold=0.25, res=7, linkage_method='average', dist='cosine', normalized=True,f="sum",model_name='clip'):
    seg_torch, seg_numpy,tokens_numpy = [], [], []
    if model_name == "dino":
        size = model.patch_embed.patch_size
        input_res = model.patch_embed.img_size
        num_token = int(input_res/size)
   
        interpret_token = interpret_token_dino
    elif model_name == "dino2":
        size = model.patch_embed.patch_size[0]
        input_res = model.patch_embed.img_size[0]
        num_token = int(input_res/size)
        interpret_token = interpret_token_dino2
    elif model_name == "clip":
        size = model.visual.conv1.stride[0]
        input_res = model.visual.input_resolution
        num_token = int(input_res/size)
        interpret_token = interpret_token_clip
    func = retrive_func(f)
    for token in (range(1, num_token**2+1)):
        if torch.is_tensor(f):
            func = return_func(f[token-1])

        r_image,token_rep = interpret_token(image, layer, token, model, device,func=func)
        r_image = preprocess_image_relevance(r_image, token, num_token, res)
        seg_numpy.append(r_image.squeeze().cpu().numpy())
        seg_torch.append(r_image.cpu())
        tokens_numpy.append(token_rep.detach().cpu().numpy())

    seg_numpy = np.array(seg_numpy).transpose(1, 0, 2)
    tokens_numpy = np.array(tokens_numpy).transpose(1, 0, 2)
    # print(tokens_numpy.shape)
    seg_torch = torch.stack(seg_torch).transpose(1, 0)

    segs = []
    tokens_clusterd = []
    j = 0
    for seg_num,seg_un_num in zip(seg_numpy,num_unique_classes):

        cosine_distances = pdist(seg_num, metric=dist)
        # if hierarchical :
        # Perform hierarchical clustering using scipy
        linkage_matrix = linkage(cosine_distances, linkage_method)
        labels = fcluster(linkage_matrix, t=seg_un_num+2,
                          criterion='maxclust')   # crit = distance , t = tresh = (0.4 for base) or crit = maxclust , t = num_clas

        # Find unique clusters
        unique_labels = np.unique(labels)
        # Initialize clustering dictionary
        clustered = {label: [] for label in unique_labels}
        token_clusterd = {label: [] for label in unique_labels}
        # tokens = [[] for _ in num_token**2]
        # Assign each segment to its cluster
        for i, label in enumerate(labels):
            clustered[label].append(seg_torch[j, i])
            token_clusterd[label].append(tokens_numpy[j,i])
            # tokens[i].append(tokens_numpy[j,i])

        # for i,token in enumerate(tokens):
        tokens_clusterd.append(token_clusterd)

        # Sum each cluster tensor
        clss = []
        if normalized:

            for cluster in clustered:
                summed_cluster = torch.stack(
                    clustered[cluster], dim=0).sum(dim=0)

                # Normalize the summed cluster tensor between 0 and 5
                min_val = summed_cluster.min()
                max_val = summed_cluster.max()
                normalized_cluster = 5 * \
                    (summed_cluster - min_val) / (max_val - min_val)

                clss.append(normalized_cluster)

        else:
            for cluster in clustered:
                clss.append(torch.stack(clustered[cluster], dim=0).sum(dim=0))

        clss = torch.stack(clss)
        seg = torch.argmax(clss, dim=0)

        seg_numpy = deepcopy(seg.reshape(res, res).detach().cpu().numpy())
        seg_reshape = cv2.resize(seg_numpy.astype(
            np.float32), (input_res, input_res), interpolation=cv2.INTER_NEAREST)
        segs.append(torch.tensor(seg_reshape))
        j+=1

    return torch.stack(segs) ,tokens_clusterd





def apply_threshold(relevance_map, threshold):
    """
    Applies a threshold to the relevance map to create a binary mask.
    """
    binary_mask = (relevance_map > threshold).float()
    return binary_mask


def compute_iou(binary_mask, ground_truth_mask):
    """
    Computes the IoU between the binary mask and the ground truth mask.
    """
    intersection = (binary_mask * ground_truth_mask).sum(dim=(1, 2))
    union = ((binary_mask + ground_truth_mask) > 0).sum(dim=(1, 2))
    iou = intersection / union
    return iou


def evaluate(config, layer, device, dataloader, model,f=None,num_batches=None):
    """
    Evaluates the model performance for a given layer and dataset.

    Args:
        config: Configuration dictionary.
        layer: The layer to use for clustering.
        device: The device (CPU or GPU).
        dataset: The dataset to evaluate on.
        dataloader: The DataLoader for the dataset.
        model: The model to use for inference.
    """
    mean_iou_scores, accuracies = [], []
    if f == None:
        f = config["model"]["func"]

    for i, batch in tqdm(enumerate(dataloader),total=len(dataloader)) :
        # desc="Evaluating batches")):
        torch.cuda.empty_cache()
        if i == num_batches:
            break

        # Handle batch format (list or dictionary)
        if isinstance(batch, list):
            img: torch.Tensor = batch[0].to(device, non_blocking=True)
            label: torch.Tensor = batch[1].to(device, non_blocking=True)
        else:
            img: torch.Tensor = batch['img'].to(device, non_blocking=True)
            label: torch.Tensor = batch['label'].to(device, non_blocking=True)

        unique_classes_per_image = [torch.unique(label[b].view(-1)) for b in range(label.shape[0])]
        unique_classes_per_image = [uc[uc != -1] for uc in unique_classes_per_image]  # Remove -1

        # Count occurrences of each class in each image
        class_counts = [{int(cls.item()): (label[b] == cls).sum().item() for cls in uc} for b, uc in enumerate(unique_classes_per_image)]

        # Compute number of unique classes per image
        num_unique_classes = torch.tensor([len(uc) for uc in unique_classes_per_image], dtype=torch.int32, device=label.device)

      
        # Use unsup_seg for clustering predictions
        cluster_preds,_ = unsup_seg(img, num_unique_classes, model, device=device,
                                  layer=layer,
                                  distance_threshold=config["clustering"]["distance_threshold"],
                                  res=config["dataset"]["res"],
                                  f=f,
                                  model_name=config["model"]['model'])

        batch_iou, batch_acc = [], []
        # print(cluster_preds.shape)
        for pred, gt in zip(cluster_preds, label):
      
            torch.cuda.empty_cache()
            pred = torch.tensor(map_to_sequential_indices(pred)).to(device)

            unknown = (gt == -1).any()
            gt = (torch.tensor(map_to_sequential_indices(gt)) - int(unknown)).to(device)
            # show_tensor_lable(pred)

            number_of_classes = len(torch.unique(gt)) - int(unknown)
            extra_classes = max(len(torch.unique(pred)) - number_of_classes, 0)

            cluster_metrics = UnsupervisedMetrics("Cluster_", number_of_classes, extra_classes, True).to(device)
            cluster_metrics.update(pred, gt)
            eval_metrics = get_metrics(cluster_metrics)

            if not np.isnan(eval_metrics['Cluster_mIoU']):
                batch_iou.append(eval_metrics['Cluster_mIoU'])
                batch_acc.append(eval_metrics['Cluster_Accuracy'])

        mean_iou_scores.append(np.mean(batch_iou))
        accuracies.append(np.mean(batch_acc))
        print(np.mean(batch_iou),np.mean(batch_acc))

        # print(f'Mean IoU: {np.mean(batch_iou):.4f}, Accuracy: {np.mean(batch_acc):.4f}')

    # Final summary of evaluation metrics
    print(f'Overall Mean IoU: {np.mean(mean_iou_scores):.4f}')
    print(f'Overall Accuracy: {np.mean(accuracies):.4f}')
    return np.mean(mean_iou_scores) , np.mean(accuracies)


import numpy as np
import torch
import cv2
from copy import deepcopy
from scipy.spatial.distance import pdist
from scipy.cluster.hierarchy import linkage, fcluster

def find_best_threshold(seg_num, seg_torch, linkage_method, dist, device, max_iter=7):
    """
    Optimizes distance_threshold to maximize mIoU in a few iterations.
    
    Args:
        seg_num: Feature vectors of the segments (numpy array)
        seg_torch: Torch tensor representations of the segments
        linkage_method: Clustering method used in scipy's linkage function
        dist: Distance metric for clustering
        device: Torch device (cuda/cpu)
        max_iter: Maximum number of iterations (default=7)
    
    Returns:
        Best distance_threshold that maximizes mIoU
    """
    low, high = 0.1, 2.0  # Reasonable search range
    best_threshold = 0.45  # Initial guess
    best_miou = -1  # Track best mIoU

    for _ in range(max_iter):
        test_thresholds = np.linspace(low, high, num=3)  # Try 3 values in each iteration
        for threshold in test_thresholds:
            labels = fcluster(linkage(pdist(seg_num, metric=dist), method=linkage_method), t=threshold, criterion='distance')
            unique_labels = np.unique(labels)
            clustered = {label: [] for label in unique_labels}

            for i, label in enumerate(labels):
                clustered[label].append(seg_torch[i])

            clss = [torch.stack(clustered[cluster], dim=0).sum(dim=0) for cluster in clustered]
            clss = torch.stack(clss).to(device)
            seg = torch.argmax(clss, dim=0)

            # Compute mIoU (mean Intersection-over-Union)
            miou = compute_miou(seg, labels, device)  # You need to implement this function

            if miou > best_miou:
                best_miou = miou
                best_threshold = threshold  # Update best threshold

        # Refine search range for next iteration
        low = max(0.1, best_threshold - 0.2)
        high = min(2.0, best_threshold + 0.2)

    return best_threshold

def unsup_seg_treshhold(image, model, device, layer=13, res=7, linkage_method='average', dist='cosine', f='sum', normalized=True, auto_threshold=True):
    """
    Unsupervised segmentation function that automatically optimizes `distance_threshold` for max mIoU.
    """
    seg_torch, seg_numpy = [], []
    size = model.visual.conv1.stride[0]
    input_res = model.visual.input_resolution
    num_token = int(input_res / size)

    for token in range(1, num_token**2 + 1):
        r_image = interpret_token(image, layer, token, model, device)
        r_image = postprocess_image_relevance(r_image, token, num_token, res)
        seg_numpy.append(r_image.squeeze().cpu().numpy())
        seg_torch.append(r_image.cpu())

    seg_numpy = np.array(seg_numpy).transpose(1, 0, 2)
    seg_torch = torch.stack(seg_torch).transpose(1, 0)

    segs = []
    for j, seg_num in enumerate(seg_numpy):
        
        # Find best threshold based on mIoU
        distance_threshold = find_best_threshold(seg_num, seg_torch[j], linkage_method, dist, device) if auto_threshold else 0.45
        print("distance_threshold" ,distance_threshold)
        # Perform hierarchical clustering
        cosine_distances = pdist(seg_num, metric=dist)
        linkage_matrix = linkage(cosine_distances, linkage_method)
        labels = fcluster(linkage_matrix, t=distance_threshold, criterion='distance')

        unique_labels = np.unique(labels)
        clustered = {label: [] for label in unique_labels}

        for i, label in enumerate(labels):
            clustered[label].append(seg_torch[j, i])

        clss = [torch.stack(clustered[cluster], dim=0).sum(dim=0) for cluster in clustered]
        clss = torch.stack(clss).to(device)
        seg = torch.argmax(clss, dim=0)

        seg_numpy = deepcopy(seg.reshape(res, res).detach().cpu().numpy())
        seg_reshape = cv2.resize(seg_numpy.astype(np.float32), (input_res, input_res), interpolation=cv2.INTER_NEAREST)
        segs.append(torch.tensor(seg_reshape))

    return torch.stack(segs)



def interpret_token(image, layer, token_id, model, device, texts=None):
    attn_blocks = [i for i in model.visual.transformer.resblocks.children()]

    x = model.visual.conv1(image.type(torch.cuda.HalfTensor))
    # shape = [*, width, grid ** 2]   [B, channel, H*W]
    x = x.reshape(x.shape[0], x.shape[1], -1)
    # shape = [*, grid ** 2, width]       [B, H*W, channel]
    x = x.permute(0, 2, 1)
    x = torch.cat([model.visual.class_embedding.to(x.dtype) + torch.zeros(x.shape[0], 1, x.shape[-1],
                  dtype=x.dtype, device=x.device), x], dim=1)  # shape = [*, grid ** 2 + 1, width]
    x = x + model.visual.positional_embedding.to(x.dtype)
    x = model.visual.ln_pre(x)
    x = x.permute(1, 0, 2)  # NLD -> LND    [H*W, B, channel]
    for i in range(len(attn_blocks)):
        x = attn_blocks[i](x)
        if i+2 == layer:
            token = x[token_id]
    x = x.permute(1, 0, 2)
    x = x = model.visual.ln_post(x[:, 0, :])
    final = x @ model.visual.proj

    batch_size = image.shape[0]
    token_sum = torch.norm(token.cuda())
    model.zero_grad()

    num_tokens = attn_blocks[0].attn_probs.shape[-1]

    R = torch.eye(num_tokens, num_tokens,
                  dtype=attn_blocks[0].attn_probs.dtype).to(device)
    R = R.unsqueeze(0).expand(batch_size, num_tokens, num_tokens)
    normal = 0
    for i, blk in enumerate(attn_blocks):
        if i+1 >= layer:
            continue
        normal += 1
        grad = torch.autograd.grad(
            token_sum, [blk.attn_probs], retain_graph=True, allow_unused=True)
        grad = grad[0].detach()
        cam = blk.attn_probs.detach()
        cam = cam.reshape(-1, cam.shape[-1], cam.shape[-1])
        grad = grad.reshape(-1, grad.shape[-1], grad.shape[-1])
        cam = grad * cam
        cam = cam.reshape(batch_size, -1, cam.shape[-1], cam.shape[-1])
        cam = cam.clamp(min=0).mean(dim=1)
        R = R + torch.bmm(cam, R)

    image_relevance = R[:, token_id, 1:]
    return image_relevance  # [batch* patch * patch]